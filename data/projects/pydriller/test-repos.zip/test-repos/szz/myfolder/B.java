class Arquivo {
  void a() {
   a();
  }
}
